import pyjsparser.parser
from flask import Flask, render_template, request, redirect, url_for, session
import base64, random, secrets, string, bcrypt, js2py

app = Flask(__name__)
pyjsparser.parser.ENABLE_PYIMPORT=False


users = {}
users_hash = {}
salt = bcrypt.gensalt()
app.secret_key = secrets.token_bytes(16)

admin = b'admin'
admin_password = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(32))
print(admin_password)

h = bcrypt.hashpw(admin, salt)
users[admin] = admin_password.encode()
users_hash[h] = bcrypt.hashpw(admin_password.encode(), salt)
print(users, users_hash)


@app.route('/')
def home():
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username: bytes = base64.b64decode(request.form['username'])
        password: bytes = base64.b64decode(request.form['password'])
        if bcrypt.hashpw(username, salt) in users_hash and users_hash[bcrypt.hashpw(username, salt)] == bcrypt.hashpw(
                password, salt):

            if (bcrypt.hashpw(username, salt) == bcrypt.hashpw(b"admin", salt) and users_hash[
                bcrypt.hashpw(username, salt)] == users_hash[bcrypt.hashpw(username, salt)] == users_hash[
                bcrypt.hashpw(b"admin", salt)]):
                session['is_admin'] = True
                return redirect(url_for('admin'))
            return f"Welcome, {username.decode()}!"
        else:
            return "Invalid username or password!"
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username: bytes = base64.b64decode(request.form['username'])
        password: bytes = base64.b64decode(request.form['password'])
        if username in users:
            return "Username already exists!"
        if len(username) > 15:
            return "username is too long"

        users[username] = password
        users_hash[bcrypt.hashpw(username, salt)] = bcrypt.hashpw(password, salt)
        print(users, users_hash)

        return f"User {username.decode()} registered successfully!"
    return render_template('register.html')


@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if session.get('is_admin'):
        if request.method == 'POST':
            js = request.form['jscode']
            if len(js) >155:
                return "too long"
            try:
                result=js2py.eval_js(js)
                return f"ok,{result}"
            except Exception as e:
                return f"An error occurred: {str(e)}"
        else:
            return render_template('admin.html')
    else:
        return redirect(url_for('login'))


if __name__ == '__main__':
    app.run()

